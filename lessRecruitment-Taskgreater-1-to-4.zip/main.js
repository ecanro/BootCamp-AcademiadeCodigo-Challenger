// Declare both totalTasks and currentHour with the provided values
// (you'll need these variables throughout the challenge).
// In order to introduce yourself to the team you should declare
// a variable and assign your name to it. After that, show us a
// greeting message with your name included.

var totalTasks = 4;
var currentHour = 9;
var greetingMessage = 'Hey, bunch of emacs losers! My name is ';
var myName = 'Edgar Canro';

console.log(greetingMessage + myName);
console.log('total Hours = ', currentHour);
console.log('total Task = ', totalTasks);

//declare new variables to find something values
let time = new Date();
let hora = time.getHours();
let minutos = time.getMinutes();
const taskCl = 'Task cleared';

console.log('***********First challenge' + '#1************');

// To solve this next task, you have to explain to Jian Yang that
// he can't leave the guts of his fish all over the kitchen sink like
// that. If you fail to do so, you have to clean it yourself.

// Every time you try to explain it to Jian Yang, you should say:
// "Do you understand?" and increase timesAsked by 1.
// Jian Yang will only understand what you want after your fourth try.
// Every time that Jian Yang doesn't understand what you want, show failedAttemptMessage.
// When Jian Yang understands what you asked him, set the variable sinkIsClean to true
// and have him yell profanities at Erlich. (What he says is up to you, of course...)

// If Jian Yang cleaned the sink for you, increase currentHour by 2.
// Otherwise, increase currentHour by 3.

// Decrease totalTasks by 1.
// If by the end of this task it's still not 6 p.m. and you still have tasks to do,
// show a message saying "Task cleared".
// If it's 6 p.m. and you've still got tasks to do, show a message saying
// "You took too long! Maybe you should try Hooli instead...".
// If it's still not 6 p.m and all the tasks are done, show a message saying
// "Welcome to Pied Piper, motherfucker!".

var totalTries = 4;
var timesAsked = 0;
var failedAttemptMessage = 'Yes. I eat the fish.';
var sinkIsClean = false;

console.log(
	'Jian you cant leave the guts of you fish all over the kitchen sink like that'
);
for (timesAsked = 1; timesAsked <= totalTries; timesAsked++) {
	console.log('Do you understand?');
	if (timesAsked <= 3) {
		console.log(failedAttemptMessage);
		//console.log('timesAsked = '+ timesAsked);
	} else {
		if (timesAsked == 4) {
			sinkIsClean = true;
			console.log(sinkIsClean);
		}
	}
}
console.log(taskCl);
currentHour = currentHour + 2;
console.log('total Hours avaliable= ' + currentHour);
totalTasks = totalTasks - 1;
console.log('total task to finish = ' + totalTasks);

console.log('***********Second challenge' + '#2************');

// Extract the necessary characters from the notes Jared handed you, in order to assemble the following sentence:
// "Fix a bug and push the new version to the remote".

// Declare a new variable which will hold the extracted characters.
// After extracting all the characters you need, print the resulting string.
// Compare the value of your newly declared variable to actualTask.

// If you got it right, increase currentHour by 2 and Jared should say:
// "Yes, that's exactly it!".
// Otherwise, increase currentHour by 3 and Jared should say:
// "Hmm... Maybe we should just wait for Richard."

// Decrease totalTasks by 1.
// If by the end of this task it's still not 6 p.m. and you still have tasks to do,
// show a message saying "Task cleared".
// If it's 6 p.m. and you've still got tasks to do, show a message saying
// "You took too long! Maybe you should try Hooli instead...".
// If it's still not 6 p.m and all the tasks are done, show a message saying
// "Welcome to Pied Piper, motherfucker!".

var taskInstructions = [
	'Fix a bug and something something remote',
	'Must push the new version to the cloud',
];
var actualTask = 'Fix a bug and push the new version to the remote';
taskInstructions = taskInstructions.toString();
taskInstructions = taskInstructions.replace(',', ' ');
taskInstructions = taskInstructions.split(' ');
actualTask = actualTask.split(' ');
var jaredTask = [];

for (i = 0; i < actualTask.length; i++) {
	for (n = 0; n <= taskInstructions.length; n++) {
		if (actualTask[i] == taskInstructions[n]) {
			if (jaredTask.indexOf(taskInstructions[n]) == -1) {
				jaredTask.push(taskInstructions[n]);
			}
		}
	}
}
jaredTask = jaredTask.toString();
var change = /,/g;
jaredTask = jaredTask.replace(change, ' ');
console.log(jaredTask);
console.log('Hmm... Maybe we should just wait for Richard.');
console.log(taskCl);
currentHour = currentHour + 3;
console.log('total Hours avaliable= ' + currentHour);
totalTasks = totalTasks - 1;
console.log('total task to finish = ' + totalTasks);

console.log('***********Third challenge' + '#3************');

// You must be able to roll 3 "Blue" in a row if you wanna get in with the guys.
// Make sure to keep track of how many times you rolled "Blue".
// If you roll "Yellow", your number of "Blue" rolls resets to zero.
// Until you get 3 "Blue" rolls, keep throwing the ball.

// After rolling 3 "Blue", you should shout: "ALWAYS BLUE, ALWAYS BLUE!!!"
// and increase currentHour by 2.

// Decrease totalTasks by 1.
// If by the end of this task it's still not 6 p.m. and you still have tasks to do,
// show a message saying "Task cleared".
// If it's 6 p.m. and you've still got tasks to do, show a message saying
// "You took too long! Maybe you should try Hooli instead...".
// If it's still not 6 p.m and all the tasks are done, show a message saying
// "Welcome to Pied Piper, motherfucker!".

var blueRollCount;

//for effects < 0.5 is yellow and >= 0.5 is blue
for (blueRollCount = 1; blueRollCount <= 3; blueRollCount++) {
	var random = Math.random();
	//console.log(random);
	//for effects < 0.5 is yellow and > is blue
	if (random >= 0.5) {
		console.log('is blue =)');
		console.log('the blueRollCount is ' + blueRollCount);
		if (blueRollCount == 3) {
			console.log('ALWAYS BLUE, ALWAYS BLUE!!!');
		}
	} else {
		console.log('is  yellow ._.');
		blueRollCount = 0;
	}
}
console.log(taskCl);
currentHour = currentHour + 2;
console.log('total Hours avaliable= ' + currentHour);
totalTasks = totalTasks - 1;
console.log('total task to finish = ' + totalTasks);

console.log('***********Fourth challenge' + '#4************');

// Declare a new variable to store all the validValues extracted from corruptData.
// To salvage the data, iterate through all corruptData's elements
// and extract only the ones matching the values inside validValues.

// If the salvaged data has 24 characters and all of them are 0's and 1's,
// increase currentHour by 2 and Gilfoyle should say: "Good job, rookie."
// Otherwise increase currentHour by 3, and Gilfoyle should say: "Guess that's that, huh?"

// Decrease totalTasks by 1.
// If by the end of this task it's still not 6 p.m. and you still have tasks to do,
// show a message saying "Task cleared".
// If it's 6 p.m. and you've still got tasks to do, show a message saying
// "You took too long! Maybe you should try Hooli instead...".
// If it's still not 6 p.m and all the tasks are done, show a message saying
// "Welcome to Pied Piper, motherfucker!".

var validValues = ['0', '1'];
var corruptData = [
	['0', '2', '0', 'E', '1', '1', 'u', '0', '1', '0', ':', '1'],
	['0', '0', '1', '9', '0', '}', '1', 'l', '1', '1', '1', '˜'],
	['x', '.', 'd', '2', '|', '[', 'z', '8', 's', 'd', '2', '5'],
	['r', '8', 'c', ']', '2', 'Z', 'H', ';', 'Á', 'l', '4', '?'],
	['Y', '0', '0', '1', '1', 'K', '1', '.', '0', 'v', '0', '1'],
];

var validData = [];
corruptData = corruptData.toString();
for (i = 0; i <= validValues.length; i++) {
	for (j = 0; j < corruptData.length; j++) {
		if (corruptData[j] == validValues[i]) {
			//use push to insert element in new array
			validData.push(corruptData[j]);
		}
	}
}
console.log(
	'the valid data is: ' +
		validData +
		' and have ' +
		validData.length +
		' characters'
);
console.log('Good job, rookie');
console.log('The current time is: ' + hora + ':' + minutos);
if (hora < 18) {
	console.log('Welcome to Pied Piper, motherfucker!');
} else {
	console.log('You took too long! Maybe you should try Hooli instead...');
}
console.log(taskCl);
currentHour = currentHour + 2;
console.log('total Hours avaliable= ' + currentHour);
totalTasks = totalTasks - 1;
console.log('total task to finish = ' + totalTasks);
